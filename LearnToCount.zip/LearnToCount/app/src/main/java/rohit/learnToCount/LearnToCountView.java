package rohit.learnToCount;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.Queue;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class LearnToCountView  extends View {

    private int spotsTouched;
    private int level;
    private int count;
    private int viewWidth;
    private int viewHeight;
    private int spot_delay = 1000;
    private long animationTime;
    private boolean gameEnd;
    private boolean dialogDisplayed;
    private CountDownTimer timer;

    private final Queue<ImageView> spots = new ConcurrentLinkedQueue<>();
    private final Queue<Animator> animators = new ConcurrentLinkedQueue<>();
    private List<String> numberQueue;
    private List<Integer> levelFourClips;
    private TextView timerTextView;
    private TextView levelTextView;
    private RelativeLayout relativeLayout;
    private Resources resources;
    private LayoutInflater layoutInflater;
    private Chronometer chronometer;

    private static final int INITIAL_ANIMATION_DURATION = 10000;
    private static final Random random = new Random();
    private static final int SPOT_DIAMETER = 100;
    private static final float SCALE_X = 0.5f;
    private static final float SCALE_Y = 0.5f;
    private static final int INITIAL_SPOTS = 10;
    private static final int NEW_LEVEL = 10;
    private Handler spotHandler;

    private static final int APPLAUSE_SOUND_ID = 31;
    private static final int UHOH_SOUND_ID = 32;
    private static final int BOO_SOUND_ID = 33;
    private static final int SOUND_PRIORITY = 1;
    private static final int MAX_STREAMS = 4;
    private SoundPool soundPool;
    private int volume;

    public LearnToCountView(Context context, RelativeLayout parentLayout)
    {
        super(context);
        resources = context.getResources();

        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        relativeLayout = parentLayout;

        chronometer = (Chronometer) relativeLayout.findViewById(R.id.chronometer);
        timerTextView = (TextView) relativeLayout.findViewById(R.id.timerTextView);
        levelTextView = (TextView) relativeLayout.findViewById(R.id.levelTextView);

        spotHandler = new Handler();
        numberQueue = new ArrayList<>();
        levelFourClips = new ArrayList<>();
    }

    @Override
    protected void onSizeChanged(int width, int height, int oldWidth, int oldHeight)
    {
        viewWidth = width;
        viewHeight = height;
    }

    public void pause()
    {
        soundPool.release();
        soundPool = null;
        cancelAnimations();
    }

    private void cancelAnimations()
    {
        for (Animator animator : animators)
            animator.cancel();

        for (ImageView view : spots)
            relativeLayout.removeView(view);

        spotHandler.removeCallbacks(addSpotRunnable);
        animators.clear();
        spots.clear();
    }

    public void resume(Context context)
    {
        initializeSoundEffects(context);

        if (!dialogDisplayed)
            resetGame();
    }

    private void initializeSoundEffects(Context context)
    {
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .setUsage(AudioAttributes.USAGE_GAME)
                .build();
        soundPool = new SoundPool.Builder()
                .setMaxStreams(MAX_STREAMS).setAudioAttributes(audioAttributes).build();

        AudioManager manager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        volume = manager.getStreamVolume(AudioManager.STREAM_MUSIC);

        for (int i = 1; i < 31; i++)
        {
            String audioClip = "voice_" + i;
            int resId = getResources().getIdentifier(audioClip, "raw", BuildConfig.APPLICATION_ID);
            soundPool.load(context, resId, SOUND_PRIORITY);
        }
        soundPool.load(context, R.raw.applause, SOUND_PRIORITY);
        soundPool.load(context, R.raw.uhoh, SOUND_PRIORITY);
        soundPool.load(context, R.raw.boo, SOUND_PRIORITY);
    }

    public void resetGame()
    {
        spots.clear();
        animators.clear();
        numberQueue.clear();
        animationTime = INITIAL_ANIMATION_DURATION;
        spotsTouched = 0;
        level = 1;
        count = 0;
        gameEnd = false;

        if(timer != null)
        {
            timer.cancel();
            timer = null;
        }

        levelTextView.setText(resources.getString(R.string.level) + " " + level);
        chronometer.setBase(SystemClock.elapsedRealtime());
        chronometer.start();
        timer = new CountDownTimer(61000, 1000) {
            public void onTick(long ms)
            {
                timerTextView.setText(resources.getString(R.string.timer, ms/1000));
            }
            public void onFinish()
            {
                if (soundPool != null)
                    soundPool.play(BOO_SOUND_ID, volume, volume, SOUND_PRIORITY, 0, 1f);
                timerTextView.setText(resources.getString(R.string.timer, 0));
                cancelAnimations();
                chronometer.stop();
                if(timer != null)
                {
                    timer.cancel();
                    timer = null;
                }

                Builder dialogBuilder = new AlertDialog.Builder(getContext());
                dialogBuilder.setTitle(R.string.game_over);
                dialogBuilder.setMessage(R.string.lost_message);
                dialogBuilder.setPositiveButton(R.string.play_again,
                        new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int which)
                            {
                                dialogDisplayed = false;
                                resetGame();
                            }
                        });
                dialogDisplayed = true;
                dialogBuilder.show();
            }
        }.start();

        for (int i = 1; i < 31; i++)
        {
            numberQueue.add("nu_" + i);
        }

        for (int i = 1; i <= INITIAL_SPOTS; ++i)
        {
            spotHandler.postDelayed(addSpotRunnable, i * spot_delay);
            count++;
        }
    }

    private Runnable addSpotRunnable = new Runnable()
    {
        public void run()
        {
            addNewSpot();
        }
    };

    public void addNewSpot()
    {
        int x = random.nextInt(viewWidth - SPOT_DIAMETER);
        int y = random.nextInt(viewHeight - SPOT_DIAMETER);
        int x2 = random.nextInt(viewWidth - SPOT_DIAMETER);
        int y2 = random.nextInt(viewHeight - SPOT_DIAMETER);

        final ImageView spot = (ImageView) layoutInflater.inflate(R.layout.number_spot, null);
        spots.add(spot);
        spot.setLayoutParams(new RelativeLayout.LayoutParams(SPOT_DIAMETER, SPOT_DIAMETER));
        String image = numberQueue.remove(0);
        spot.setImageResource(getResources().getIdentifier(image, "drawable",
                BuildConfig.APPLICATION_ID));
        spot.setX(x);
        spot.setY(y);
        spot.setOnClickListener(
                new OnClickListener()
                {
                    public void onClick(View v)
                    {
                        touchedSpot(spot);
                    }
                });
        relativeLayout.addView(spot);
        spot.animate().x(x2).y(y2).scaleX(SCALE_X).scaleY(SCALE_Y)
                .setDuration(animationTime).setListener(
                new AnimatorListenerAdapter()
                {
                    @Override
                    public void onAnimationStart(Animator animation)
                    {
                        animators.add(animation);
                    }

                    public void onAnimationEnd(Animator animation)
                    {
                        // Nothing to do
                    }
                });
    }

    private void levelUp()
    {
        ++level;
        animationTime *= 0.95;

        View layout = layoutInflater.inflate(R.layout.toast,
                (ViewGroup) findViewById(R.id.toast_message));
        TextView levelUpTextView = (TextView) layout.findViewById(R.id.levelUpTextView);
        TextView levelTimeTextView = (TextView) layout.findViewById(R.id.levelTimeTextView);
        Toast toast = new Toast(getContext());

        switch (level)
        {
            case 2:
                levelTextView.setText(resources.getString(R.string.level) + " " + level);
                levelUpTextView.setText(R.string.leveled_up_2);
                levelTimeTextView.setText(R.string.level_2_time);
                toast.setDuration(Toast.LENGTH_LONG);
                toast.setView(layout);
                toast.show();
                if(timer != null)
                {
                    timer.cancel();
                    timer = null;
                }
                timer = new CountDownTimer(56000, 1000) {
                    public void onTick(long ms)
                    {
                        timerTextView.setText(resources.getString(R.string.timer, ms/1000));
                    }
                    public void onFinish()
                    {
                        if (soundPool != null)
                            soundPool.play(BOO_SOUND_ID, volume, volume, SOUND_PRIORITY, 0, 1f);
                        timerTextView.setText(resources.getString(R.string.timer, 0));
                        cancelAnimations();
                        chronometer.stop();
                        if(timer != null)
                        {
                            timer.cancel();
                            timer = null;
                        }
                        Builder dialogBuilder = new AlertDialog.Builder(getContext());
                        dialogBuilder.setTitle(R.string.game_over);
                        dialogBuilder.setMessage(R.string.lost_message);
                        dialogBuilder.setPositiveButton(R.string.play_again,
                                new DialogInterface.OnClickListener()
                                {
                                    public void onClick(DialogInterface dialog, int which)
                                    {
                                        dialogDisplayed = false;
                                        resetGame();
                                    }
                                });
                        dialogDisplayed = true;
                        dialogBuilder.show();
                    }
                }.start();
                break;
            case 3:
                levelTextView.setText(resources.getString(R.string.level) + " " + level);
                levelUpTextView.setText(R.string.leveled_up_3);
                levelTimeTextView.setText(R.string.level_3_time);
                toast.setDuration(Toast.LENGTH_LONG);
                toast.setView(layout);
                toast.show();
                if(timer != null)
                {
                    timer.cancel();
                    timer = null;
                }
                timer = new CountDownTimer(51000, 1000) {
                    public void onTick(long ms)
                    {
                        timerTextView.setText(resources.getString(R.string.timer, ms/1000));
                    }
                    public void onFinish()
                    {
                        if (soundPool != null)
                            soundPool.play(BOO_SOUND_ID, volume, volume, SOUND_PRIORITY, 0, 1f);
                        timerTextView.setText(resources.getString(R.string.timer, 0));
                        cancelAnimations();
                        chronometer.stop();
                        if(timer != null)
                        {
                            timer.cancel();
                            timer = null;
                        }
                        Builder dialogBuilder = new AlertDialog.Builder(getContext());
                        dialogBuilder.setTitle(R.string.game_over);
                        dialogBuilder.setMessage(R.string.lost_message);
                        dialogBuilder.setPositiveButton(R.string.play_again,
                                new DialogInterface.OnClickListener()
                                {
                                    public void onClick(DialogInterface dialog, int which)
                                    {
                                        dialogDisplayed = false;
                                        resetGame();
                                    }
                                });
                        dialogDisplayed = true;
                        dialogBuilder.show();
                    }
                }.start();
                break;
            case 4:
                levelTextView.setText(resources.getString(R.string.level) + " " + level);
                levelUpTextView.setText(R.string.leveled_up_4);
                levelTimeTextView.setText(R.string.level_4_time);
                toast.setDuration(Toast.LENGTH_LONG);
                toast.setView(layout);
                toast.show();
                if(timer != null)
                {
                    timer.cancel();
                    timer = null;
                }
                timer = new CountDownTimer(46000, 1000) {
                    public void onTick(long ms)
                    {
                        timerTextView.setText(resources.getString(R.string.timer, ms/1000));
                    }
                    public void onFinish()
                    {
                        if (soundPool != null)
                            soundPool.play(BOO_SOUND_ID, volume, volume, SOUND_PRIORITY, 0, 1f);
                        timerTextView.setText(resources.getString(R.string.timer, 0));
                        cancelAnimations();
                        chronometer.stop();
                        if(timer != null)
                        {
                            timer.cancel();
                            timer = null;
                        }
                        Builder dialogBuilder = new AlertDialog.Builder(getContext());
                        dialogBuilder.setTitle(R.string.game_over);
                        dialogBuilder.setMessage(R.string.lost_message);
                        dialogBuilder.setPositiveButton(R.string.play_again,
                                new DialogInterface.OnClickListener()
                                {
                                    public void onClick(DialogInterface dialog, int which)
                                    {
                                        dialogDisplayed = false;
                                        resetGame();
                                    }
                                });
                        dialogDisplayed = true;
                        dialogBuilder.show();
                    }
                }.start();
                numberQueue.clear();
                levelFourClips.clear();
                while(levelFourClips.size() < 10)
                {
                    int randomNumber = random.nextInt(31);
                    if (!levelFourClips.contains(randomNumber) && randomNumber != 0)
                    {
                        levelFourClips.add(randomNumber);
                    }
                }
                Collections.sort(levelFourClips);
                for (int i = 0; i < INITIAL_SPOTS; ++i)
                {
                    numberQueue.add("nu_" + levelFourClips.get(i));
                }
                break;
            default:
                break;
        }
    }

    private void touchedSpot(ImageView spot)
    {
        if (spot != spots.peek())
        {
            if (soundPool != null)
            {
                soundPool.play(UHOH_SOUND_ID, volume, volume, SOUND_PRIORITY, 0, 1f);
            }
            return;
        }

        relativeLayout.removeView(spot);
        spots.remove(spot);
        ++spotsTouched;

        if (spotsTouched % NEW_LEVEL == 0)
        {
            levelUp();
        }

        if (soundPool != null)
        {
            if (level != 4 || spotsTouched == 30)
                soundPool.play(spotsTouched, volume, volume, SOUND_PRIORITY, 0, 1f);
            else
                soundPool.play(levelFourClips.remove(0), volume, volume, SOUND_PRIORITY, 0, 1f);
        }

        if (!gameEnd && (spotsTouched == (level - 1) * 10 ))
        {
            for (int i = 1; i <= INITIAL_SPOTS; ++i)
            {
                spotHandler.postDelayed(addSpotRunnable, i * spot_delay);
                count++;
            }
        }

        if (count == 40)
            gameEnd = true;

        if (spotsTouched == count)
        {
            if (soundPool != null)
                soundPool.play(APPLAUSE_SOUND_ID, volume, volume, SOUND_PRIORITY, 0, 1f);
            cancelAnimations();
            chronometer.stop();
            if(timer != null)
            {
                timer.cancel();
                timer = null;
            }
            Builder dialogBuilder = new AlertDialog.Builder(getContext());
            dialogBuilder.setTitle(R.string.congratulations);
            dialogBuilder.setMessage(R.string.win_message);
            dialogBuilder.setPositiveButton(R.string.play_again,
                    new DialogInterface.OnClickListener()
                    {
                        public void onClick(DialogInterface dialog, int which)
                        {
                            dialogDisplayed = false;
                            resetGame();
                        }
                    });
            dialogDisplayed = true;
            dialogBuilder.show();
        }
    }
}