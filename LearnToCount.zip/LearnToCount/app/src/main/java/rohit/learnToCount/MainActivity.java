package rohit.learnToCount;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    private LearnToCountView view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RelativeLayout layout = (RelativeLayout) findViewById(R.id.relativeLayout);
        view = new LearnToCountView(this, layout);
        layout.addView(view, 0);
    }

    @Override
    public void onPause()
    {
        super.onPause();
        view.pause();
    }

    @Override
    public void onResume()
    {
        super.onResume();
        view.resume(this);
    }
}